
			IWSLT 2016 Human Evaluation

			FBK - Fondazione Bruno Kessler
					Trento, Italy

1. Overview

This package contains the data used for the human evaluation of the IWSLT 2016 campaign.

Human evaluation was carried out on primary runs submitted by participants to two of the official MT TED tasks, namely English-German (EnDe) and English-French (EnFr). 

The human evaluation (HE) dataset created for each MT task was a subset of the official test set (tst2015). Both the EnDe and EnFr tst2015 datasets are composed of 12 TED Talks, and the first 56% of each talk was selected. The resulting HE sets are identical and composed of 600 segments, each corresponding to around 10,000 words.

Human evaluation was based on Post-Editing, i.e. the manual correction of the MT system output, which was carried out by professional translators.

As regards the MT system outputs evaluated, we followed two different criteria:

EnDe: all 4 IWSLT 2016 submitted systems + 1 IWSLT 2015 submitted system. In total we have 4 new reference translations + 1 reference translation taken from IWSLT 2015

EnFr: 2 IWSLT 2016 systems +  1 IWSLT 2015 system + Google Translate + ModernMT. In total, 5 new reference translations were created.


2. Contents

./data/

This directory contains two directories, one for each task:

- IWSLT16.TED.tst2015.MT_ende
- IWSLT16.TED.tst2015.MT_enfr

Each task directory contains:

- IWSLT16.TED.tst2015.MT_XX.SysOut/
	The output of the evaluated systems
	
- IWSLT16.TED.tst2015.MT_XX.PEdits/
	The human post-edits of the systems' output

- IWSLT16.TED.tst2015.MT_XX.Src.txt
	The source text (transcripts of the talks available 
	at the TED website)
	
- IWSLT16.TED.tst2015.MT_XX.OrigRef.txt
	The reference translation (manual translations of the talks
 	available at the TED website)
 	
- IWSLT16.TED.tst2015.MT_XX.idx.txt
	Talk-sentence IDs
	
	
./docs/
  
This directory contains the documentation for this package:

- README.txt (this file)
  
- IWSLT_2016_Overview.pdf
	

3. Acknowledgments and Copyright information

- TED talks are copyrighted by TED Conference LLC and licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0

- The collection of post-edits was funded by the CRACKER project (EU’s Horizon 2020 research and innovation programme, grant agreement no. 645357)

- Post-edits are released under a Creative Commons Attribution (CC-BY) 4.0 International License. If you use them in your work, please cite the following paper:
Mauro Cettolo, Jan Niehues, Sebastian Stüker, Luisa Bentivogli, Roldano Cattoni, Marcello Federico. 2016. "The IWSLT 2016 Evaluation Campaign". Proceedings of the International Workshop on Spoken Language Translation (IWSLT-2016), Seattle (US-WA), 8-9 December 2016.

4. Contact Information

For further information about this data release, contact:
Luisa Bentivogli    <bentivo@fbk.eu>
Roldano Cattoni <cattoni@fbk.eu>